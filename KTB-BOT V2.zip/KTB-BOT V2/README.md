<p align="center">
<img src="https://avatars.githubusercontent.com/ZeusFtrOfc" width="225" height="225"/>
</p>
<p align="center">
<a href="#"><img title="Whatsapp-Bot" src="https://img.shields.io/badge/Whatsapp Bot-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center">
<a href="https://github.com/ZeusFtrOfc"><img title="Author" src="https://img.shields.io/badge/AUTHOR-Zeus-blue.svg?style=for-the-badge&logo=github"></a>
<p align="center">
<a href="https://github.com/ZeusFtrOfc/followers"><img title="Followers" src="https://img.shields.io/github/followers/mhankbarbar?color=blue&style=flat-square"></a>
<a href="https://github.com/TobyG74/megumikato2/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/TobyG74/ElainaBOT?color=red&style=flat-square"></a>
<a href="https://github.com/ZeusFtrOfc/Zeus_whatsapp-bot/network/members"><img title="Forks" src="https://img.shields.io/github/forks/ZeusFtrOfc/Zeus_whatsapp-bot?color=red&style=flat-square"></a>
<a href="https://github.com/ZeusFtrOfc/Zeus_whatsapp-bot/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/ZeusFtrOfc/Zeus_whatsapp-bot?label=Watchers&color=blue&style=flat-square"></a>
<a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2FUrbaee%2Fwhatsapp-bot2&count_bg=%232396FF&title_bg=%23555555&icon=meteor.svg&icon_color=%23F5F9FF&title=visitor&edge_flat=false"/></a>
</p>

  
  
  
<p align="left">
<a href="https://github.com/ZeusFtrOfc/Zeus_whatsapp-bot">
 <img align="center" src="https://github-readme-stats.vercel.app/api/pin/?username=ZeusFtrOfc&repo=Zeus_whatsapp-bot&theme=dark" />
  </p>

  
  
## Things I Code With
<p>
    <img
        src="https://img.shields.io/badge/node.js%20-%2343853D.svg?&style=for-the-badge&logo=node.js&logoColor=white" />
    <img
        src="https://img.shields.io/badge/javascript%20-%23323330.svg?&style=for-the-badge&logo=javascript&logoColor=%23F7DF1E" />
  
  
 
<p align="center"><a href="https://wa.me/622299427739?text=%23menu" target="_blank">Zeus Whatsapp BOT New!</a>.</p>
</div>



## Getting Started

This project require NodeJS v12.

### Install
Clone this project

```bash
> git clone https://github.com/ZeusFtrOfc/Zeus_whatsapp-bot.git
> cd Zeus_whatsapp-bot
```

Install the dependencies:

```bash
> npm install 
> npm install gify-cli -g
```

### Usage
Run the Whatsapp bot

```bash
> npm start
```

after running it you need to scan the qr

And sussces!!

### Information
- Change ownerNumber on [this section](https://github.com/ZeusFtrOfc/Zeus_whatsapp-bot/blob/main/HandleMsg.js#L136)
- Change groupLimit on [this section](https://github.com/ZeusFtrOfc/Zeus_whatsapp-bot/blob/master/settings/setting.json#L3)
- Change memberLimit on [this section](https://github.com/ZeusFtrOfc/Zeus_whatsapp-bot/blob/master/settings/setting.json#L4)
- Change prefix on [this section](https://github.com/ZeusFtrOfc/Zeus_whatsapp-bot/blob/master/settings/setting.json#L5)
- Change menu on [this section](https://github.com/ZeusFtrOfc/Zeus_whatsapp-bot/blob/master/lib/menu.js#L32)
- Add kata kasar on [this section](https://github.com/ZeusFtrOfc/Zeus_whatsapp-bot/blob/master/lib/kataKotor.js#L8)
- Change all apiKey on [this section](https://github.com/ZeusFtrOfc/Zeus_whatsapp-bot/blob/master/settings/api.json)
- Get Api NoBackground on [this website](https://www.remove.bg/)
- Get Api ScreenShot on [this website](https://apiflash.com/)
- `vhtear`: VHTear API token. You can get it [here](https://wa.me/6282139549692) your can buy my apikey on number whatsapp me.

---

## Features

| 18+ Anime |Yes|
| ------------- | ------------- |
| Nekopoi |✅|
| Random Hentai|✅|
| Random Hug|✅|
| Random Blowjob|✅|
| Random Baka|✅|
| Rhentai|✅|
| Random Pussy|✅|
| Random Slap|✅|
| Random Waifu|✅|
| Random Nsfw|✅|
| Random Kiss|✅|
| Random Cum|✅|
| Gif Hentai|✅|
| Neko NSFW|✅|
| Random Neko|✅|
| Boobs|✅|


| Creator |Yes|
| ------------- | ------------- |
| Respond img to sticker|✅|
| Sticker To Image|✅|
| TTP|✅|
| Respond img to sticker no bg|✅|
| Respond url to sticker|✅|
| Respond gif to sticker|✅|
| Respond giphy url to sticker|✅|
| Make a meme from photo|✅|
| Quotes maker result pict|✅|
| Nulis Bot|✅|
| Glitch Text Maker|✅|
| Harta Tahta|✅|

| Islam |Yes|
| ------------- | ------------- |
| List Surah|✅|
| Info Surah|✅|
| Surah|✅|
| Tafsir Alquran|✅|
| Alquran Audio/Voice|✅|
| Jadwal solat|✅|

| Downloader |Yes|
| ------------- | ------------- |
| Youtube Music |✅|
| Youtube Video |✅|
| Facebook |✅|
| Instagram |✅|

| Fun Group! |Yes|
| ------------- | ------------- |
| Simi-simi BOT|✅|
| Anti kata kasar|✅|
| Family 100|✅|
| Cak Lontong|✅|
| Tebak Gambar|✅|

| Primbon |Yes|
| ------------- | ------------- |
| Arti nama |✅|
| Cek Jodoh |✅|

| Searchs |Yes|
| ------------- | ------------- |
| Images |✅|
| Subreddit |✅|
| Resep makanan |✅|
| Stalk IG |✅|
| Wikipedia |✅|
| Cuaca |✅|
| Chord musik |✅|
| Lirik musik |✅|
| Screen Crot!|✅|
| Play music|✅|
| whats anime?|✅|

| Random text |Yes|
| ------------- | ------------- |
| Pantun pakboy|✅|
| Fakta Menarik|✅|
| Kata Bijak|✅|
| Quotes|✅|
| Cerita Sex|✅|
| Cerita Pendek|✅|
| Puisi|✅|

| Random image |Yes|
| ------------- | ------------- |
| Anime |✅|
| Kpop |✅|
| Memes |✅|


| Others |Yes|
| ------------- | ------------- |
| Teks to Sound/Voice|✅|
| Translate teks|✅|
| Get covid info from map|✅|
| Covid-19 Indo|✅|
| Shortlink|✅|
| Bap4k F0nt|✅|
| Get Group Link|✅|
| Get Admin List|✅|
| Get List Blocked|✅|
| Get List Banned|✅|
| Get Group Info|✅|
| Get Profile Info|✅|
| Steal Picture|✅|
| Brainly|✅|
| Matematika|✅|
| Rate Me|✅|
| Kapan|✅|
| Apakah|✅|
| Bisakah|✅|
| Nulis3|✅|
| Nulis4|✅|
| Nulis5|✅|
| Covid19 dunia|✅|
| Nulis6|✅|
| joox|✅|
| brainly work|✅|
| Ai Quote|✅|
| Doggo|✅|
| Get Owner Group|✅|
| Dewa Batch|✅|
| How Much in Group|✅|
| Group Bot|✅|
| WP Anime|✅|
| Penyegar Timeline|✅|
| Google Search|✅|
| Sider|✅|
| Bokep|✅|
| Bokep 2|✅|
| Wallpaper|✅|
| Wallpaper 2|✅|
| Neko|✅|
| Loli|✅|
| Loli NSFW|✅|
| Baka!|✅|
| Waifu|✅|
| Anime Avatar|✅|
| Say List|✅|
| Add Say!|✅|
| Say!|✅|
| Delete Say|✅|
| Bacot List|✅|
| Add Bacot|✅|
| Bacot|✅|
| Delete Bacot|✅|
| Tag|✅|
| Get User Picture|✅|
| Jadian|✅|
| Ava|✅|
| KBBI|✅|
| Logo Pornhub|✅|
| Truth or Dare|✅|
| Distance|✅|
| Shopee|✅|
| Play Store|✅|
| YouTube Search|✅|
| Play Youtube Video|✅|
| Simi|✅|
| Kusonime|✅|
| Arti Mimpi|✅|
| Emoji To Sticker|✅|
| Asupan|✅|
| fml|✅|
| memeindo|✅|
| drakjokes|✅|
| xxnx|✅|
| missing|✅|

| Images |Yes|
| --------------- | ----------- |
| Aesthetic|✅|
| Amelia Andani|✅|
| Random Cecan|✅|
| Random Cogan|✅|

| Groups |Yes|
| ------------- | ------------- |
| Owner||
| Kick all members|✅|
| Admin||
| Add user|✅|
| Kick user|✅|
| Promote User|✅|
| Demote User|✅|
| Mute Group|✅|
| Change Group icon|✅|
| Delete bot msg|✅|
| Tagall/mentions all|✅|
| Revoke Link Group|✅|
| Set Group Name|✅|
| Resend Messages|✅|
| Anti Link|✅|

| Owner bot |Yes|
| ------------- | ------------- |
| Broadcast|✅|
| Leave all group|✅|
| Delete all msgs|✅|
| Banned user|✅|
| Set Status Bot|✅|
| Set Name Bot|✅|
| Screenshot Session|✅|
| DLL|✅|

## To-Do
 - Add Media Downloader
 - Add More Feature
 - More refactoring
 
---

## Troubleshooting
Make sure all the necessary dependencies are installed: https://github.com/puppeteer/puppeteer/blob/main/docs/troubleshooting.md

Fix Stuck on linux, install google chrome stable: 
```bash
> wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb
> sudo apt install ./google-chrome-stable_current_amd64.deb
```

## Thanks to
- [ArugaZ](https://github.com/ArugaZ)
